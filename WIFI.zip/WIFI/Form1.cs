﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Security;
using System.Security.Principal;

namespace WIFI
{
    public partial class Form1 : Form
    {
        Process newProcess = new Process();
        public Form1()
        {
            newProcess.StartInfo.UseShellExecute = false;
            newProcess.StartInfo.CreateNoWindow = true;
            newProcess.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
            InitializeComponent();
            
          
            
        }

        private void label2_Click(object sender, EventArgs e) { }

        public bool isUserAdministrator()
        {
            bool isAdmin;
            try
            {
                WindowsIdentity user = WindowsIdentity.GetCurrent();
                WindowsPrincipal principal = new WindowsPrincipal(user);
                isAdmin = principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
            catch (UnauthorizedAccessException)
            { isAdmin = false; }
            catch (Exception)
            { isAdmin = false; }

            return isAdmin;
        }

        public void Process_start_1()
        {
            newProcess.StartInfo.FileName = "netsh";
            newProcess.StartInfo.Arguments = "wlan stop hostednetwork";
            try
            {
                using (Process execute = Process.Start(newProcess.StartInfo))
                {
                    execute.WaitForExit();
                    Process_start_2();
                }
            } catch (Exception) { }
        }

        public void Process_start_2()
        {
            
            newProcess.StartInfo.FileName = "netsh";
            newProcess.StartInfo.Arguments = "wlan set hostedNetwork mode=allow ssid="+txtUserName.Text +" key=" + txtPassword.Text;
            try
            {
                using (Process execute = Process.Start(newProcess.StartInfo))
                {
                    execute.WaitForExit();
                    Process_start_3();
                }
            }
            catch (Exception) { }
        }

        public void Process_start_3()
        {
            newProcess.StartInfo.FileName = "netsh";
            newProcess.StartInfo.Arguments = "wlan start hostednetwork";
            try
            {
                using (Process execute = Process.Start(newProcess.StartInfo))
                {
                    execute.WaitForExit();
                    btnStart.Text = "stop";
                    btnStart.BackColor = System.Drawing.Color.Red;
                    txtUserName.Enabled = false;
                    txtPassword.Enabled = false;
                }
            }
            catch (Exception) { }
        }

        public void Process_stop()
        {
            newProcess.StartInfo.FileName = "netsh";
            newProcess.StartInfo.Arguments = "wlan stop hostednetwork";
            try
            {
                using (Process execute = Process.Start(newProcess.StartInfo))
                {
                    execute.WaitForExit();
                    txtPassword.Enabled = true;
                    txtUserName.Enabled = true;
                    btnStart.BackColor = System.Drawing.Color.Green;
                    btnStart.Text = "Start";
                 
                }
            }
            catch (Exception) { }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
           
           
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click_1(object sender, EventArgs e)
        {

            if (btnStart.Text.ToLower() == "start")
            {

                if (txtUserName.TextLength < 1)
                { MessageBox.Show("UserName length must be greater than 1", "UserName Error"); }
                else if (txtPassword.TextLength < 8)
                { MessageBox.Show("Password length must be greater than 8", "Password Error"); }
                else
                {
                    Process_start_1();
                }
            }
            else
            {
                Process_stop();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
            Process_stop();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;//Mimizing the window ==========
            
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == ">")
            {
                button1.Text = "^";
                panel1.Visible = true;
                ProcessStartInfo p = new ProcessStartInfo("netsh", "wlan show hostednetwork");
                p.UseShellExecute = false;
                p.CreateNoWindow = true;
                p.RedirectStandardOutput = true;
                var pr = Process.Start(p);
                string s = pr.StandardOutput.ReadToEnd();
                int m = s.IndexOf("Hosted network status");
                string g = s.Substring(267);
                label4.Text = g;

            }
            else if(button1.Text=="^")
            {
                button1.Text = ">";
                panel1.Visible = false;
            }
            else
            { MessageBox.Show("Something wrong happened", "Error"); }
        }
    }
}
